import tkinter

root = tkinter.Tk()
root.title('Kalpak')
lab = tkinter.Label(None , text = 'This is a label.' )
lab.pack()
root.mainloop()
