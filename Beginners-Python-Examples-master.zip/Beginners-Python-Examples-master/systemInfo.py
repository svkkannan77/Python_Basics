import platform  
import os  
import sys

print('============================')
print('System Information : ')
print(os.name)  
print(platform.system())  
print(platform.release(),'\n')
print('============================')
print('Python Version Installed : ')
print(sys.version,'\n')
print('============================')
