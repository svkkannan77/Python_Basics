from math import *
#pi for calculations
def pie():
	get_from_user = int(input("Enter number:"))
	get_from_use = int(input("Enter next number:"))
	get_users_view = input("Enter operator like + - / * :"))
	if get_from_user == "pi" and get_users_view == "+":
		print(get_from_user+get_from_use)
	elif get_from_use == "pi" and get_users_view == "+":
		print(get_from_user+get_from_use)

	if get_from_user == "pi" and get_users_view == "-":
		print(get_from_user-get_from_use)
	elif get_from_use == "pi" and get_users_view == "-":
		print(get_from_user-get_from_use)

    if get_from_user == "pi" and get_users_view == "*":
		print(get_from_user*get_from_use)
	elif get_from_use == "pi" and get_users_view == "*":
		print(get_from_user*get_from_use)

	if get_from_user == "pi" and get_users_view == "/":
		print(get_from_user/get_from_use)
	elif get_from_use == "pi" and get_users_view == "/":
		print(get_from_user/get_from_use)	

