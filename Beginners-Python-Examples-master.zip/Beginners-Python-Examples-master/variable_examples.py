# below is an example of varible
# variable is created by = to sign and is known an assignment operator

message = "Hello Python!"
print(message)
