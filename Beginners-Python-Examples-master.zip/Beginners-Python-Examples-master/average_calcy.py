# Simple averaging function
def average(x):
	return sum(x) / len(x)
 
data = [12, 546, 8, 2, 34, 8, 67, 34, 5, 876, 3456, 76]
print(average(data))	
